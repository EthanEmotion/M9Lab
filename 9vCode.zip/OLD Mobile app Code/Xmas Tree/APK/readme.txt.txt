103 -> stable (old)
104 -> stable - parametri corretti di defaut
105 -> test ->utf8 (fallito)
106 -> test ->elimina "ricevuto" da stringa iniziale
107 -> stable -> velicità scalate
